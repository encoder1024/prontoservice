<?php

//TODO: voy a armar una api para esta consulta que se ejecutará una vez a la semana, los lunes. 
//Voy a usar la api existente en la carpeta pspia en public del server.