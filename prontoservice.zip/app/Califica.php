<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Califica extends Model
{
    //
}
