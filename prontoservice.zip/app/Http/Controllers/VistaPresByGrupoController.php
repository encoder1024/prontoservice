<?php

namespace App\Http\Controllers;

use App\VistaPresByGrupo;
use Illuminate\Http\Request;

class VistaPresByGrupoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\VistaPresByGrupo  $vistaPresByGrupo
     * @return \Illuminate\Http\Response
     */
    public function show(VistaPresByGrupo $vistaPresByGrupo)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\VistaPresByGrupo  $vistaPresByGrupo
     * @return \Illuminate\Http\Response
     */
    public function edit(VistaPresByGrupo $vistaPresByGrupo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\VistaPresByGrupo  $vistaPresByGrupo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, VistaPresByGrupo $vistaPresByGrupo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\VistaPresByGrupo  $vistaPresByGrupo
     * @return \Illuminate\Http\Response
     */
    public function destroy(VistaPresByGrupo $vistaPresByGrupo)
    {
        //
    }
}
